/*------------------------------------------------------------------------------
 *******************************************************************************
 * COPYRIGHT Ericsson 2012
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 *******************************************************************************
 *----------------------------------------------------------------------------*/
package com.pack.search.ui;

import java.awt.GridBagConstraints;

import javax.swing.JPanel;

public class ControlPanel extends JPanel {
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    public final static int HORIZONTAL_FULL = GridBagConstraints.HORIZONTAL;
    public final static int VERTICAL_FULL = GridBagConstraints.VERTICAL;
    public final static int BOTH = GridBagConstraints.BOTH;
    public final static int NONE = GridBagConstraints.NONE;
    public final static int HALF = 5001;
    public final static int HORIZONTAL_HALF = 5002;
    public final static int VERTICAL_HALF = 5003;
    private boolean isExpandable = true;
    private int expandPolicy = BOTH;

    private double weightX = 1;
    private double weightY = 1;

    /**
     * @return the weightx
     */
    public double getWeightX() {
        return weightX;
    }

    /**
     * @param weightX
     *            the weightx to set
     */
    public ControlPanel setWeightX(double weightX) {
        this.weightX = weightX;
        return this;
    }

    /**
     * @return the weighty
     */
    public double getWeightY() {
        return weightY;
    }

    /**
     * @param weightY
     *            the weighty to set
     */
    public ControlPanel setWeightY(double weightY) {
        this.weightY = weightY;
        return this;
    }

    public ControlPanel() {
    }

    public ControlPanel(boolean expandble, int expandPolicy) {
        this.isExpandable = expandble;
        this.expandPolicy = expandPolicy;
    }

    public boolean isExpandable() {
        return this.isExpandable;
    }

    public ControlPanel setExpandable(boolean expand) {
        this.isExpandable = expand;
        return this;
    }

    public int getExpandPolicy() {
        return this.expandPolicy;
    }

    public ControlPanel setExpandPolicy(int expandPolicy) {
        this.expandPolicy = expandPolicy;
        return this;
    }
}
