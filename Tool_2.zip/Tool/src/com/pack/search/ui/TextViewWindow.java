/*------------------------------------------------------------------------------
 *******************************************************************************
 * COPYRIGHT Ericsson 2012
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 *******************************************************************************
 *----------------------------------------------------------------------------*/
package com.pack.search.ui;

import java.awt.*;

import javax.swing.*;

public class TextViewWindow extends JFrame {
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    private JTextPane viewPane = new JTextPane();

    public TextViewWindow() {
        super();
        this.viewPane.setEditable(false);
        this.init();
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        this.setSize(800, 600);
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        this.setLocation(dim.width / 2 - this.getSize().width / 2, dim.height / 2 - this.getSize().height / 2);
        this.setVisible(true);
    }

    public JTextPane getTextView() {
        return this.viewPane;
    }

    public TextViewWindow setWindowTitle(String title) {
        this.setTitle(title);
        return this;
    }

    public TextViewWindow init() {
        this.setLayout(new GridLayout(1, 1));
        JScrollPane scrollPane = new JScrollPane(viewPane);
        this.add(scrollPane);
        return this;
    }

    public void setContent(String content) {
        this.viewPane.setText(content);
    }

    public void addContent(String content) {
        getTextView().setText(this.viewPane.getText() + content);
    }

    public TextViewWindow showContent(String content) {
        this.getTextView().setText(content);
        return this;
    }
    public void showContent(String content , String title) {
        this.getTextView().setText(content);
        this.setTitle(title);
    }

}
