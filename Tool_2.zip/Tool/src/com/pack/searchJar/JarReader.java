/*------------------------------------------------------------------------------
 *******************************************************************************
 * COPYRIGHT Ericsson 2012
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 *******************************************************************************
 *----------------------------------------------------------------------------*/
package com.pack.searchJar;

import java.io.*;
import java.util.jar.*;

public class JarReader {
    private File file;
    public JarReader(String path) {
        file = new File(path);
    }
    
    public JarReader(File file){
        this.file=file;
    }
    
    public String getContent(String entryName){
        return getContent(entryName, null);
    }
    
    public String getContent(String entyName,String secondParent){
        String content="";
        
               if(file !=null && file.exists() && file.canRead()){
                   if(JarSearch.isValidArchive(file.getName())){
                       StringBuilder builder = new StringBuilder();
                       try {
                        JarFile jarFile = new JarFile(file);
                        if(secondParent!=null){
                        //                            JarInputStream jarIn =new JarInputStream(jarFile.getInputStream(jarFile.getJarEntry(entyName)));
                        //                            JarEntry childEntry =null;
                        //                            while((childEntry=jarIn.getNextJarEntry())!=null){
                        //                                if(childEntry.getName().equals(entyName)){
                        //                                    jarIn.
                        //                                }
                        //                            }
                        }else{
                            JarEntry jarEntry = jarFile.getJarEntry(entyName);
                            BufferedInputStream reader = new BufferedInputStream(jarFile.getInputStream(jarEntry));
                            int read =-1;
                            while((read=reader.read())!=-1){
                                builder.append((char)read);
                            }
                            reader.close();
                            jarFile.close();
                            content = builder.toString();
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                   }else{
                       //Do something ?
                   }
               }else{
                   //Do something ?
               }
        return content;
    }
}
