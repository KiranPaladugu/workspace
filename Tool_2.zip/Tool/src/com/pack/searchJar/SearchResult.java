/*------------------------------------------------------------------------------
 *******************************************************************************
 * COPYRIGHT Ericsson 2012
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 *******************************************************************************
 *----------------------------------------------------------------------------*/
package com.pack.searchJar;

import java.util.*;

public class SearchResult extends Result {
    private String file;
    private String actualName;
    private List<Result> results = new ArrayList<Result>();
    private List<SearchResult> resultList = new Vector<SearchResult>();
    private boolean empty;
    private List<Message> errors = new Vector<Message>();

    /**
	 * 
	 */
    public SearchResult() {
        this.empty = false;
    }

    public SearchResult(boolean empty) {
        this.empty = empty;
    }

    public boolean isEmpty() {
        return empty;
    }

    public void setEmpty(boolean value) {
        this.empty = value;
    }

    public String getFile() {
        return file;
    }

    public void setFile(String file) {
        setName(file);
        this.file = file;
    }

    public int getResultCount() {
        return results.size();
    }

    public void addResult(Result name) {
        results.add(name);
    }

    public List<Result> getAllResults() {
        return results;
    }

    public void addSearchResult(SearchResult result) {
        this.resultList.add(result);
    }

    public List<SearchResult> getOtherResults() {
        return this.resultList;
    }

    /**
     * @return the errors
     */
    public List<Message> getErrors() {
        return errors;
    }

    /**
     * @param error the errors to set
     */
    public void addError(Message error) {
        this.errors.add(error);
    }

    /**
     * @return the actualName
     */
    public String getActualName() {
        return actualName;
    }

    /**
     * @param actualName the actualName to set
     */
    public void setActualName(String actualName) {
        this.setValue(actualName);
        this.actualName = actualName;
    }
    
    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return file;
    }
}