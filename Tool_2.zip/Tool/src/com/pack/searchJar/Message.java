/*------------------------------------------------------------------------------
 *******************************************************************************
 * COPYRIGHT Ericsson 2012
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 *******************************************************************************
 *----------------------------------------------------------------------------*/
package com.pack.searchJar;

public class Message {
    public static enum MESSAGE_TYPE{
        INFO,MESSAGE,WARN,ERROR,FATAL,NOTIFICATION
    }

    private MESSAGE_TYPE messageType;
    private String message;
    private String description;
    private Object source;
    
    public String getMessageType() {
        return messageType.name();
    }
    
    public MESSAGE_TYPE getEnumMessageType() {
        return messageType;
    }
    
    public void setMessageType(MESSAGE_TYPE messageType) {
        this.messageType = messageType;
    }
    public String getMessage() {
        return message;
    }
    public void setMessage(String message) {
        this.message = message;
    }
    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * @return the source
     */
    public Object getSource() {
        return source;
    }

    /**
     * @param source the source to set
     */
    public void setSource(Object source) {
        this.source = source;
    }

    @Override
    public String toString() {
        return "Message [messageType=" + messageType + ", message=" + message + ", description=" + description + ", source="
                + source + "]";
    }
    
    
}
