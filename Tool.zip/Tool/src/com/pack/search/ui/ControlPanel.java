/*------------------------------------------------------------------------------
 *******************************************************************************
 * COPYRIGHT Ericsson 2012
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 *******************************************************************************
 *----------------------------------------------------------------------------*/
package com.pack.search.ui;

import javax.swing.JPanel;

public class ControlPanel extends JPanel {
    public static final int HORIZONTAL_EXPAND = 1;
    public static final int VERTICAL_EXPAND = 2;
    public static final int FULL_EXPANSION = 3;
    private boolean isExpandable = true;
    private int expandPolicy = FULL_EXPANSION;

    private double weightX = 1;
    private double weightY = 1;

    /**
     * @return the weightx
     */
    public double getWeightX() {
        return weightX;
    }

    /**
     * @param weightX
     *            the weightx to set
     */
    public ControlPanel setWeightX(double weightX) {
        this.weightX = weightX;
        return this;
    }

    /**
     * @return the weighty
     */
    public double getWeightY() {
        return weightY;
    }

    /**
     * @param weightY
     *            the weighty to set
     */
    public ControlPanel setWeightY(double weightY) {
        this.weightY = weightY;
        return this;
    }

    public ControlPanel() {
    }

    public ControlPanel(boolean expandble, int expandPolicy) {
        this.isExpandable = expandble;
        this.expandPolicy = expandPolicy;
    }

    public boolean isExpandable() {
        return this.isExpandable;
    }

    public ControlPanel setExpandable(boolean expand) {
        this.isExpandable = expand;
        return this;
    }

    public int getExpandPolicy() {
        return this.expandPolicy;
    }

    public ControlPanel setExpandPolicy(int expandPolicy) {
        this.expandPolicy = expandPolicy;
        return this;
    }
}
