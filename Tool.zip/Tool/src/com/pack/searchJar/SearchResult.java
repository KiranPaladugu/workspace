/*------------------------------------------------------------------------------
 *******************************************************************************
 * COPYRIGHT Ericsson 2012
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 *******************************************************************************
 *----------------------------------------------------------------------------*/
package com.pack.searchJar;

import java.util.*;

public class SearchResult {
    private String file;
    private List<String> names = new ArrayList<String>();
    private List<SearchResult> resultList = new Vector<SearchResult>();
    private boolean empty;
    private List<String> errors = new Vector<String>();

    /**
	 * 
	 */
    public SearchResult() {
        this.empty = false;
    }

    public SearchResult(boolean empty) {
        this.empty = empty;
    }

    public boolean isEmpty() {
        return empty;
    }

    public void setEmpty(boolean value) {
        this.empty = value;
    }

    public String getFile() {
        return file;
    }

    public void setFile(String file) {
        this.file = file;
    }

    public int getOccurance() {
        return names.size();
    }

    public void addFoundFile(String name) {
        names.add(name);
    }

    public List<String> getFoundFiles() {
        return names;
    }

    public void addSearchResult(SearchResult result) {
        this.resultList.add(result);
    }

    public List<SearchResult> getOtherResults() {
        return this.resultList;
    }

    /**
     * @return the errors
     */
    public List<String> getErrors() {
        return errors;
    }

    /**
     * @param error the errors to set
     */
    public void addError(String error) {
        this.errors.add(error);
    }
}