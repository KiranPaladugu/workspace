/*------------------------------------------------------------------------------
 *******************************************************************************
 * COPYRIGHT Ericsson 2012
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 *******************************************************************************
 *----------------------------------------------------------------------------*/
package com.pack.searchJar;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.jar.*;

public class JarSearch {
    /**
	 * 
	 */

    private String javaArchive[] = { ".ear", ".war", ".jar" };
    private String searchPath = null;
    private String searchFile = null;
    private List<String> searchPaths = new Vector<String>();

    public JarSearch(String path, String file) {
        this.searchFile = file;
        if (path != null && path.length() > 0) {
            this.searchPath = path;
            if (!searchPaths.contains(path)) {
                searchPaths.add(path);
            }
        }
        // doSearch();
    }

    public String getPath() {
        return this.searchPath;
    }

    public void addSearchPath(String searchPath) {
        this.searchPath = searchPath;
        if (!searchPaths.contains(searchPath)) {
            searchPaths.add(searchPath);
        }
    }

    public void setSearchString(String searchString) {
        this.searchFile = searchString;
    }

    public String getSearchString() {
        return this.searchFile;
    }

    public List<SearchResult> doSearch() {
        List<SearchResult> results = new Vector<SearchResult>();
        try {
            for (String searchPath : searchPaths) {
                List<SearchResult> list = searchFileOrPath(new File(searchPath));
                if (!list.isEmpty()) {
                    results.addAll(list);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
        }
        return results;
    }

    private List<SearchResult> searchFileOrPath(File pathToSearch) {
        // System.out.println("search Path : "+pathToSearch);
        List<SearchResult> jarsList = new Vector<SearchResult>();
        if (pathToSearch != null && pathToSearch.exists()) {
            if (pathToSearch.isFile()) {
                // System.out.println("search File : "+pathToSearch);
                if (isValidArchive(pathToSearch.getName())) {
                    List<SearchResult> results = doSearchIn(pathToSearch);
                    if (!results.isEmpty()) {
                        jarsList.addAll(results);
                    }
                }
            } else if (pathToSearch.isDirectory()) {
                // System.out.println("search Directory : "+pathToSearch);
                File[] list = getFileList(pathToSearch);
                if (list != null && list.length > 0)
                    for (File file : list) {
                        List<SearchResult> foundJars = searchFileOrPath(file);
                        if (!foundJars.isEmpty()) {
                            jarsList.addAll(foundJars);
                        }
                    }
            }
        }
        return jarsList;
    }

    private List<SearchResult> doSearchIn(File jarFile) {
        List<SearchResult> results = new Vector<SearchResult>();
        if (jarFile != null) {
            try {
                JarFile jar = new JarFile(jarFile);
                Enumeration<JarEntry> entries = jar.entries();

                SearchResult result = null;
                // System.out.println("Cheking Jar .. : "+jarFile.getName());
                while (entries.hasMoreElements()) {
                    JarEntry entry = entries.nextElement();
                    try {
                        result = searchInJar(jarFile.getAbsolutePath(), jar, result, entry);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                }
                if (result != null)
                    results.add(result);

                jar.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return results;
    }

    //    private String getChildJarName(String name) {
    //        int x = name.lastIndexOf(File.pathSeparator);
    //        System.out.println("string : index :" + x);
    //        System.out.println("string : lenght :" + name.length());
    //        System.out.println("String :" + name);
    //        return name.substring(x, name.length() - 1);
    //    }

    /**
     * @param jarFile
     * @param jar
     * @param result
     * @param entry
     * @return
     * @throws IOException
     */
    private SearchResult searchInJar(String jarFile, JarFile jar, SearchResult result, JarEntry entry) throws IOException {
        String packedName = buildPackagedName(entry);
        // System.out.println("  >Cheking entry .. : "+packedName+" -- "+entry.getName().contains(searchFile));
        if (isValidArchive(entry.getName())) {

            // jar.getInputStream(jar.getEntry(entry.getName()))
            JarInputStream jarIn = new JarInputStream(jar.getInputStream(entry));
            JarEntry childJar = null;
            SearchResult childResult = new SearchResult(true);
            while ((childJar = jarIn.getNextJarEntry()) != null) {
                //                 System.out.println("Searching in child Jar:"+childJar.getName());
                try {
                    childResult = searchInJar(entry.getName(), jar, childResult, childJar);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            if (childResult != null && !childResult.isEmpty()) {
                if (result == null) {
                    result = new SearchResult(true);
                }
                if (result.isEmpty()) {
                    result.setFile(jarFile);
                    result.setEmpty(false);
                }
                result.addSearchResult(childResult);
                ;
            }
            jarIn.close();
        }
        if (packedName.contains(searchFile)) {
            if (result == null) {
                result = new SearchResult(true);
            }
            if (result.isEmpty()) {
                result.setFile(jarFile);
                result.setEmpty(false);
            }
            result.addFoundFile(packedName);
        }
        return result;
    }

    private boolean isValidArchive(String packageName) {
        boolean flag = false;
        for (String arhive : this.javaArchive) {
            if (packageName.endsWith(arhive) || packageName.endsWith(arhive.toUpperCase())) {
                flag = true;
                break;
            }
        }
        return flag;
    }

    private String buildPackagedName(JarEntry entry) {
        String packageName = "";
        String name = entry.getName().replace("/", ".");
        if (name.endsWith(".")) {
            name = name.substring(0, name.length() - 1);
        }
        packageName = name;
        return packageName;
    }

    public File[] getFileList(File path) {
        if (path != null && path.exists() && path.isDirectory()) {
            return path.listFiles();
        }
        return null;
    }

    public void printResult(List<SearchResult> list,String pos) {
        if(pos == null){
            pos="";
        }
        if (list.isEmpty()) {
            System.out.println("Nothing found..");
        }
        for (SearchResult result : list) {
            System.out.println(pos+"JarFile :" + result.getFile() + " - occurance : " + result.getOccurance());
            for (String name : result.getFoundFiles()) {
                System.out.println(pos+"  >> File :" + name);
            }

            if (!result.getOtherResults().isEmpty()) {
                System.out.println(pos+"-------------------");
                System.out.println(pos+"=>[START] child of :"+result.getFile());
                printResult(result.getOtherResults(),(pos+"    "));
                System.out.println(pos+"=>[END] child of :"+result.getFile());
                System.out.println(pos+"-------------------");
            }

        }
    }

    public static void main(String args[]) {
        if (args.length<2){
            System.out.println("Invalid aruments or emtpy argument..\n argument Length:"+args.length);
            System.out.println("Usage : java JarSearch <searchString> <searchPath>");
            return ;
        }
        JarSearch search = new JarSearch("", "");
        search.addSearchPath(args[1]);
        search.setSearchString(args[0]);
        List<SearchResult> list = search.doSearch();
        search.printResult(list,"");
    }
}
