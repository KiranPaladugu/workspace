/*------------------------------------------------------------------------------
 *******************************************************************************
 * COPYRIGHT Ericsson 2012
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 *******************************************************************************
 *----------------------------------------------------------------------------*/
package com.pack.serarch;

import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.List;
import java.util.concurrent.Semaphore;

import javax.swing.*;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;

import com.pack.search.ui.*;
import com.pack.searchJar.JarSearch;
import com.pack.searchJar.SearchResult;

public class Mainwindow extends JFrame {
    private JLabel lbl_currentSearch;
    private JTextField txt_search, txt_path;
    private JButton browse;
    private JTree resultTree;
    private ButtonController controller = new ButtonController();
    private Mainwindow window;
    private Semaphore semaphore = new Semaphore(1);
    private boolean searchProgess;

    private Mainwindow() {
        window = this;
        init();

    }

    /**
	 * 
	 */
    private void init() {
        txt_search = new JTextField("");
        txt_path = new JTextField("");
        resultTree = new JTree();
        final DefaultMutableTreeNode rootNode = new DefaultMutableTreeNode("Results");
        final DefaultTreeModel treeModel = new DefaultTreeModel(rootNode);
        resultTree.setModel(treeModel);
        lbl_currentSearch = new JLabel(" ");
        browse = new JButton("Browse");
        JPanel input = LayoutUtils.arrageComponantsInRow(null, false, LayoutUtils.HORIZONTAL_FILL, ((ControlPanel) LayoutUtils
                .arrageComponantsInRow("Enter Search String", true, txt_search)).setExpandPolicy(ControlPanel.HORIZONTAL_EXPAND),
                ((ControlPanel) LayoutUtils.arrageComponantsInColoumn("Select Path", true, txt_path, browse))
                        .setExpandPolicy(ControlPanel.HORIZONTAL_EXPAND), controller, new JSeparator(),
                ((ControlPanel) LayoutUtils.arrageComponantsInColoumn(new JScrollPane(resultTree)))
                        .setExpandPolicy(ControlPanel.FULL_EXPANSION), new JSeparator(), lbl_currentSearch);
        
        controller.getOk().addActionListener(new SearchHelper(resultTree, lbl_currentSearch));

        controller.getCancel().addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    semaphore.acquire();
                } catch (InterruptedException e1) {
                    e1.printStackTrace();
                }
                txt_search.setText("");
                txt_path.setText("");
                final DefaultTreeModel treeModel = new DefaultTreeModel(new DefaultMutableTreeNode("Results"));
                resultTree.setModel(treeModel);
                treeModel.reload();
                resultTree.repaint();
                semaphore.release();

            }
        });

        controller.getClose().addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                boolean exit = true;
                if (searchProgess) {
                    int value = JOptionPane.showConfirmDialog(window, "Search is in progress.. do you really want to exit ?",
                            "Confirmation", JOptionPane.YES_NO_OPTION);
                    if (value == JOptionPane.NO_OPTION) {
                        exit = false;
                    }
                }
                if (exit)
                    window.setVisible(false);
                System.exit(0);
            }
        });

        browse.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                JFileChooser fileChooser = new JFileChooser();
                fileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
                fileChooser.showOpenDialog(window);
                File file = fileChooser.getSelectedFile();
                if (file == null) {
                    file = fileChooser.getCurrentDirectory();
                }
                txt_path.setText(file.getAbsolutePath());

            }
        });
        this.add(input);
    }

    public static void main(String args[]) {
        try {
            // Set cross-platform Java L&F (also called "Metal")
            UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
            //            javax.swing.UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
        } catch (UnsupportedLookAndFeelException e) {
            // handle exception
        } catch (ClassNotFoundException e) {
            // handle exception
        } catch (InstantiationException e) {
            // handle exception
        } catch (IllegalAccessException e) {
            // handle exception
        }
        SwingUtilities.invokeLater(new StartUI());
    }

    /**
     * @author ekirpal
     *
     */
    public final class SearchHelper implements ActionListener {
        /**
		 * 
		 */
        private final DefaultMutableTreeNode rootNode;
        private JTree tree;
        private JLabel status;

        /**
         * @param rootNode
         * @param lbl_currentSearch
         */
        public SearchHelper(JTree tree, JLabel lbl_currentSearch) {
            this.rootNode = new DefaultMutableTreeNode("Result");
            this.tree = tree;
            tree.removeAll();
            tree.setModel(new DefaultTreeModel(rootNode));
            this.status = lbl_currentSearch;
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            rootNode.removeAllChildren();
            ((DefaultTreeModel) tree.getModel()).reload();
            tree.repaint();
            if (txt_search.getText().isEmpty() || txt_path.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Input required... ", "Error", JOptionPane.ERROR_MESSAGE);
            } else {
                SearchThread thread = new SearchThread(rootNode);
                thread.start();
            }

        }

        public final class SearchThread extends Thread {
            private final DefaultMutableTreeNode rootNode;

            /**
			 * 
			 */
            public SearchThread(DefaultMutableTreeNode rootNode) {
                this.rootNode = rootNode;
            }

            public void run() {
                try {
                    semaphore.acquire();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                controller.getOk().setEnabled(false);
                controller.getCancel().setEnabled(false);
                searchProgess = true;
                status.setText("Please wait while Searching....");
                JarSearch search = new JarSearch("", "");
                search.addSearchPath(txt_path.getText().trim());
                search.setSearchString(txt_search.getText().trim());
                List<SearchResult> results = search.doSearch();
                buildResultTree(results, rootNode);
                if (results.isEmpty()) {
                    rootNode.setUserObject("No results available");
                } else {
                    rootNode.setUserObject("Results");
                }
                ((DefaultTreeModel) tree.getModel()).reload();
                resultTree.repaint();
                resultTree.expandRow(0);
                status.setText("Done..");
                controller.getOk().setEnabled(true);
                controller.getCancel().setEnabled(true);
                searchProgess = false;
                semaphore.release();
            }

            /**
             * @param results
             */
            private void buildResultTree(List<SearchResult> results, DefaultMutableTreeNode rootNode) {
                for (SearchResult result : results) {
                    if (result != null) {
                        DefaultMutableTreeNode node = new DefaultMutableTreeNode(result.getFile());
                        List<String> founds = result.getFoundFiles();
                        for (String found : founds) {
                            DefaultMutableTreeNode nn = new DefaultMutableTreeNode(found);
                            node.add(nn);
                        }
                        if (!result.getOtherResults().isEmpty()) {
                            buildResultTree(result.getOtherResults(), node);
                        }
                        rootNode.add(node);
                    }
                }
            }
        }
    }

    static class StartUI implements Runnable {
        public void run() {
            Mainwindow window = new Mainwindow();
            // window.setResizable(false);
            window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            window.setSize(800, 630);
            window.setTitle("Jar Search...");
            Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
            window.setLocation(dim.width / 2 - window.getSize().width / 2, dim.height / 2 - window.getSize().height / 2);
            window.setVisible(true);
        }
    }
}
